export class Item {
    constructor(_key, _itemName, _itemDescription) {
        this.key = _key;
        this.itemName = _itemName;
        this.itemDescription = _itemDescription;
    }
}
//# sourceMappingURL=Items.js.map